package user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Test;
import dao.TestDao;

@WebServlet("/UserDashboard")
public class UserDashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UserDashboard() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		if(session != null && session.getAttribute("user_id") != null) {
			try {
				ArrayList<Test> arr = TestDao.getAllTests();
				ArrayList<String> allTopics = TestDao.getAllTopics();
				ArrayList<String> allLang = TestDao.getAllLang();
				
				request.setAttribute("allTopics", allTopics);
				request.setAttribute("allLang", allLang);
				request.setAttribute("tests", arr);
				request.getRequestDispatcher("./userPages/userDashboard.jsp").forward(request, response);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			response.sendRedirect("/Assesment_Portal/userPages/userLogin.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
