package user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import mail.SendMail;

@WebServlet("/UserRegister")

public class UserRegister extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    public UserRegister() {
        super();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("name");
		String mobile = (String) session.getAttribute("mobile");
		String password = (String) session.getAttribute("password");
		String email = (String) session.getAttribute("email");
		String otp = (String) session.getAttribute("otp");
		
		try {
			String code = "";
			for(int i=1; i<=6; i++) {
				code += request.getParameter("digit"+i);
			}
			System.out.println("code: " + code);
			System.out.println("otp: " + otp);
			if(!code.equals(otp)) {
				response.sendRedirect("/Assesment_Portal/userPages/userRegister.jsp?error=wrong_otp");
			}else {
				// create new user 	
				if(UserDao.addUser(name, mobile, password, email)) {
					
					String subject = "Registeration success!";
					String to = email;
					String msg = "Dear ," + name +  ",\n"
							+ "Thank you for registering with TakeTest! You are now part of our community.";
					SendMail obj = new SendMail();
					boolean success = obj.send(subject, msg, to);
					
					
					session.invalidate();
					PrintWriter out = response.getWriter();
					out.println("<script> alert('User registered successfully!'); window.location.href='/Assesment_Portal/userPages/userLogin.jsp'; </script>");
					out.close();
				}
				else response.sendRedirect("/Assesment_Portal/userPages/userRegister.jsp?error=try_again");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
