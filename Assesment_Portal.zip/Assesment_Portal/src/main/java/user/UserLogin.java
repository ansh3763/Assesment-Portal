package user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;

@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public UserLogin() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String mobile = request.getParameter("mobile");
		String password = request.getParameter("password");

		try {
			int user_id = UserDao.getUserId(mobile, password);
			if (user_id != -1) {
				String name = UserDao.getUserName(mobile);

				HttpSession session = request.getSession();
				session.setAttribute("user_id", user_id);
				session.setAttribute("name", name);

				response.sendRedirect("/Assesment_Portal/UserDashboard");
			} else {
				response.sendRedirect("/Assesment_Portal/userPages/userLogin.jsp?error=1");
				System.out.println("not a valid user");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
