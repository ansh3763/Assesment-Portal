package mail;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Contact")
public class Contact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Contact() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("name") != null) {
			
			String subject = "New message from Contact Form";
			String to = "ansh3763.be21@chitkara.edu.in";
			String msg = "Dear Admin, \n"
					+ "You have received a new message from the contact form on your website. Here are the details:\n\n"
					+ "Name: " + request.getParameter("name") + "\n"
					+ "Email: " + request.getParameter("email") + "\n"
					+ "Phone Number: " + request.getParameter("phone") + "\n"
					+ "Message: " + request.getParameter("text") + "\n\n"
					+ "Please respond to this inquiry promptly.\n\n"
					+ "Thank you,\n"
					+ "Take Test";
			
			SendMail obj = new SendMail();
			boolean success = obj.send(subject, msg, to);
			
			PrintWriter out = response.getWriter();
			if(success) out.println("<script> alert('Message sent successfully!'); window.location.href='index.html'; </script>");
			else out.println("<script> alert('Message not sent!'); window.location.href='index.html'; </script>");
			out.close();
		} else response.sendRedirect("index.html");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
