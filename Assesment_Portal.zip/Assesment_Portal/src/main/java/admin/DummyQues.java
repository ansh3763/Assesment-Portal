package admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.TestDao;

@WebServlet("/DummyQues")

public class DummyQues extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DummyQues() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int test_id = Integer.parseInt(request.getParameter("test_id"));
		TestDao.addDummyQues(test_id);
		response.sendRedirect("/Assesment_Portal/EditTest?test_id="+test_id);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
