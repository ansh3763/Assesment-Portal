package admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.TestDao;

@WebServlet("/DeleteTest")

public class DeleteTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DeleteTest() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			if(request.getParameter("what").equals("ques")) {
				String ques_id = request.getParameter("ques_id");
				HttpSession session = request.getSession();
				int test_id = (int)session.getAttribute("test_id");
				TestDao.deleteQues(ques_id, test_id);
				
				request.setAttribute("test_id", test_id);
				response.sendRedirect("/Assesment_Portal/EditTest?test_id="+test_id);
				return;
			}
//			if(request.getParameter("what").equals("test")) {
				String test_id = request.getParameter("test_id");
				TestDao.deleteTest(test_id);
				response.sendRedirect("/Assesment_Portal/AdminDashboard");				
//			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
